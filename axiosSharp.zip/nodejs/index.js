const sharp = require('sharp')
console.log(sharp,' is the sharp')
